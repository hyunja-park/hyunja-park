package com.ict.guestbook.model;

import java.util.List;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook.db.GuestBookVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookListCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		
		// DB가서 guestbook 모든 정보 가져오기
		List<GuestBookVO> gb_list = GuestBookDAO.guestBookListAll();		
		request.setAttribute("gb_list", gb_list);
		
		String gb_idx = request.getParameter("gb_idx");
		String gb_name = request.getParameter("gb_name");
		String gb_subject = request.getParameter("gb_subject");
		String gb_regdate = request.getParameter("gb_regdate");
		
		request.setAttribute("gb_name", gb_name);
		request.setAttribute("gb_subject", gb_subject);
		request.setAttribute("gb_regdate", gb_regdate);
		
				
		return "view/guestbook/list.jsp";
	}

}
