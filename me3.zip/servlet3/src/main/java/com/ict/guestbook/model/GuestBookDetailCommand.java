package com.ict.guestbook.model;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook.db.GuestBookVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookDetailCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		// 파라미터 
		String gb_idx = request.getParameter("gb_idx");
		
		// VO저장(단, 파라미터가 하나일때 vo에 저장 할 필요 없음)
		// select 문을 사용하여 0-여러개일 경우  : List<XXXVO>이다.
		// select 문을 사용하여 하나만 반드시 나올때는 결과가 XXXVO 이다.
		
		GuestBookVO gbvo = GuestBookDAO.guestSelectOne(gb_idx);
		request.setAttribute("gbvo", gbvo);
		
		return "view/guestbook/onelist.jsp";
	}

}
