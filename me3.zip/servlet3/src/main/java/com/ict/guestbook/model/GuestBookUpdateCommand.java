package com.ict.guestbook.model;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook.db.GuestBookVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookUpdateCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String gb_idx = request.getParameter("gb_idx");
		String gb_pw = request.getParameter("gb_pw");
		
		// gb_idx를 이용해서 한사람의 상세정보를 가져오기
		GuestBookVO gbvo = GuestBookDAO.guestSelectOne(gb_idx);
		request.setAttribute("gbvo", gbvo);
				
		return "view/guestbook/update.jsp";
	}

}
