package com.ict.guestbook.model;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook.db.GuestBookVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookWriteOKCommand implements Command {

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {		
		// 파라미터
		String gb_name = request.getParameter("gb_name");
		String gb_subject = request.getParameter("gb_subject");
		String gb_email = request.getParameter("gb_email");
		String gb_pw = request.getParameter("gb_pw");		
		String gb_content = request.getParameter("gb_content");

		// DB에 정보를 넣을 vo
		GuestBookVO gvo = new GuestBookVO();		
		gvo.setGb_name(gb_name);
		gvo.setGb_subject(gb_subject);
		gvo.setGb_email(gb_email);
		gvo.setGb_pw(gb_pw);
		gvo.setGb_content(gb_content);
		
		int result = GuestBookDAO.guestBookInsert(gvo);
		if (result>0) {
			return "GuestbookController?cmd=g_list";
		}else {
			return "GuestBookController?cmd=g_list";
		}

		
	}

}
