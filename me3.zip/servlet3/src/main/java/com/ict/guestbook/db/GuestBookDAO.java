package com.ict.guestbook.db;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class GuestBookDAO {
	private static SqlSession ss;
	
	private synchronized static SqlSession getSession() {
		if(ss == null) {
			ss = GuestBookDBservice.getFactory().openSession();
		}
		return ss;
	}

	public static List<GuestBookVO> guestBookListAll(){
		List<GuestBookVO> gb_list = null;
		gb_list = getSession().selectList("guestbook.g_list"); 
		return gb_list;
	}
	
	// insert, update, delete 는 반드시 commit 해야 된다.
	public static int guestBookInsert(GuestBookVO gvo) {
		int result = 0 ;
		result = getSession().insert("guestbook.g_insert", gvo);
		ss.commit();
		return result;
	}
	
	public static GuestBookVO guestSelectOne(String gb_idx) {
		GuestBookVO gbvo = null;
		gbvo = getSession().selectOne("guestbook.g_detail", gb_idx);
		return gbvo;
	 }
	
	public static int guestBookDelet(String gb_idx) {
		int result = 0;
	    result = getSession().delete("guestbook.g_delete", gb_idx);
	    ss.commit();
		return result;
		
	}
	
	public static int guestBookUpdate(GuestBookVO gbvo) {
		int result = 0;
	    result = getSession().update("guestbook.g_update", gbvo);
	    ss.commit();
		return result;
	}
}
