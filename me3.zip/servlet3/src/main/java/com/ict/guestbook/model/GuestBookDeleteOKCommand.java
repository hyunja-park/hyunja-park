package com.ict.guestbook.model;

import com.ict.guestbook.db.GuestBookDAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookDeleteOKCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String gb_idx = request.getParameter("gb_idx");
		int result = GuestBookDAO.guestBookDelet("gb_idx");
		
				
		return "GuestBookController?cmd=g_list";
	}

}
