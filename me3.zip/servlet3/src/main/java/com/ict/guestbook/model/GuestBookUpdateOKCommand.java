package com.ict.guestbook.model;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook.db.GuestBookVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBookUpdateOKCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String gb_idx = request.getParameter("gb_idx");
		String gb_name = request.getParameter("gb_name");
		String gb_subject = request.getParameter("gb_subject");
		String gb_email = request.getParameter("gb_email");
		String gb_content = request.getParameter("gb_content");
		
		GuestBookVO gbvo = new GuestBookVO();		
		gbvo.setGb_idx(gb_idx);
		gbvo.setGb_name(gb_name);
		gbvo.setGb_subject(gb_subject);
		gbvo.setGb_email(gb_email);
		gbvo.setGb_content(gb_content);
		
		int result = GuestBookDAO.guestBookUpdate(gbvo);
		
		return "GuestBookController?cmd=g_detail&gb_idx="+gb_idx;
	}

}
