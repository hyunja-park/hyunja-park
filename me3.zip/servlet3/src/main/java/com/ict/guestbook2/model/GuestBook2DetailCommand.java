package com.ict.guestbook2.model;

import com.ict.guestbook2.db.GuestBook2DAO;
import com.ict.guestbook2.db.GuestBook2VO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBook2DetailCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		
		String gb2_idx = request.getParameter("gb2_idx");
		
		GuestBook2VO gb2vo = GuestBook2DAO.guestBook2Detail(gb2_idx);
		request.setAttribute("gb2vo", gb2vo);
		
		return "view/guestbook2/onelist.jsp";
	}

}
