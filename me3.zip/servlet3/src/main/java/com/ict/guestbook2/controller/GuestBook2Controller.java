package com.ict.guestbook2.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.ict.guestbook2.model.Command;
import com.ict.guestbook2.model.GuestBook2DeleteCommand;
import com.ict.guestbook2.model.GuestBook2DeleteOKCommand;
import com.ict.guestbook2.model.GuestBook2DetailCommand;
import com.ict.guestbook2.model.GuestBook2ListCommand;
import com.ict.guestbook2.model.GuestBook2UpdateCommand;
import com.ict.guestbook2.model.GuestBook2UpdateOKCommand;
import com.ict.guestbook2.model.GuestBook2WriteCommand;
import com.ict.guestbook2.model.GuestBook2WriteOKCommand;

@WebServlet("/GuestBook2Controller")
@MultipartConfig
public class GuestBook2Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
 
		
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String cmd = request.getParameter("cmd");
		
		Command comm = null;
		switch (cmd) {
			case "gb2_list": comm = new GuestBook2ListCommand(); break;
			case "gb2_write": comm = new GuestBook2WriteCommand(); break;
			case "gb2_write_ok": comm = new GuestBook2WriteOKCommand(); break;
			case "gb2_detail": comm = new GuestBook2DetailCommand(); break;
			case "gb2_update": comm = new GuestBook2UpdateCommand(); break;
			case "gb2_update_ok": comm = new GuestBook2UpdateOKCommand(); break;			
			case "gb2_delete": comm = new GuestBook2DeleteCommand(); break;			
			case "gb2_delete_ok": comm = new GuestBook2DeleteOKCommand(); break;
		
		}		
		String path = comm.exec(request, response);
		request.getRequestDispatcher(path).forward(request, response);						

	}
}

	

