package com.ict.guestbook2.model;


import com.ict.guestbook2.db.GuestBook2DAO;
import com.ict.guestbook2.db.GuestBook2VO;
import com.oreilly.servlet.multipart.Part;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBook2UpdateOKCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		try {
			String path = request.getServletContext().getRealPath("view/upload");
			String gb2_idx = request.getParameter("gb2_idx");
			String gb2_name = request.getParameter("gb2_name");
			String gb2_subject= request.getParameter("gb2_subject");
			String gb2_content = request.getParameter("gb2_content");
			String gb2_email = request.getParameter("gb2_email");
			String gb2_pw = request.getParameter("gb2_pw");
			String odd_f_name = request.getParameter("odd_f_name");

			GuestBook2VO gb2vo = new GuestBook2VO();		
			gb2vo.setGb2_idx(gb2_idx);
			gb2vo.setGb2_name(gb2_name);
			gb2vo.setGb2_subject(gb2_subject);
			gb2vo.setGb2_content(gb2_content);
			gb2vo.setGb2_email(gb2_email);
			gb2vo.setGb2_email(gb2_pw);

			// part가 null인지를 알수 없다. => (part.getSize() >0 )
			Part part = request.getPart("gb2_f_name");
			String gb2_f_name = "";
			
			if (part != null && part.getSize() > 0) {
				// 파일명이 있는 경우만 파일명 가져오기				
				gb2_f_name = part.getSubmittedFileName();
				
			if(gb2_f_name)	
				
			}else {
				gb2_f_name = odd_f_name;
			}
				String uploadPath = path + "/" + gb2_f_name;
				part.write(uploadPath);
			}
			
			gb2vo.setGb2_f_name(gb2_f_name);
		   }
		int result = GuestBook2DAO.guestBook2Update(gb2vo);
		if(result > 0) {
			return "GuestBook2Controller?cmd=gb2_detail&gb2_idx="+ gb2_idx;




		} catch (Exception e) {
			System.out.println(e);
			return "view/guestbook2/error.jsp";
		}

		return null;
	}
}