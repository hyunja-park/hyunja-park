package com.ict.guestbook2.model;

import com.ict.guestbook2.db.GuestBook2DAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBook2DeleteOKCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String gb2_idx = request.getParameter("gb2_idx");
		
		int result = GuestBook2DAO.guestBook2Delete("gb2_idx");
		if(result>0) {
			return "GuestBook2Controller?cmd=gb2_list";
			
		}else {
			return "view/guestbook2/error.jsp";
		}
		
	}

}
