package com.ict.guestbook2.model;

import com.ict.guestbook2.db.GuestBook2DAO;
import com.ict.guestbook2.db.GuestBook2VO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

public class GuestBook2WriteOKCommand implements Command {

	private GuestBook2VO gb2vo;

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String path = request.getServletContext().getRealPath("view/upload");
		try {
			String gb2_name = request.getParameter("gb2_name");
			String gb2_subject = request.getParameter("gb2_subject");
			String gb2_email = request.getParameter("gb2_email");
			String gb2_pw = request.getParameter("gb2_pw");
			String gb2_content = request.getParameter("gb2_content");

			GuestBook2VO gvo = new GuestBook2VO();
			gb2vo.setGb2_name(gb2_name);
			gb2vo.setGb2_subject(gb2_subject);
			gb2vo.setGb2_email(gb2_email);
			gb2vo.setGb2_pw(gb2_pw);
			gb2vo.setGb2_content(gb2_content);

			Part part = request.getPart("gb2_f_name");
			String gb2_f_name ="";	
			// 파일이 없을때
			if (part == null) {
				gb2_f_name = "";
			}else {
				gb2_f_name =part.getSubmittedFileName();
				String uploadPath = path + "/" + gb2_f_name;
				// 파일 저장
				part.write(uploadPath);
				  
				// 파일명이 없을때
				if (gb2_f_name == null || gb2_f_name.isEmpty()) {
					gb2_f_name = "";
				}
				
				  gb2vo.setGb2_f_name(gb2_f_name);
			}
			
			int result = GuestBook2DAO.guestBook2Insert(gb2vo); 
			if (result >0) {
				return "GuestBook2Controller?cmd=gb2_list";
			}
			return "view/guestbook2/error.jsp";
		} catch (Exception e) {
			return "view/guestbook2/error.jsp";
		}

	}

}
