package com.ict.guestbook2.model;

import java.util.List;

import com.ict.guestbook.db.GuestBookDAO;
import com.ict.guestbook2.db.GuestBook2DAO;
import com.ict.guestbook2.db.GuestBook2VO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBook2ListCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		List<GuestBook2VO> gb2_list = GuestBook2DAO.guestBook2ListAll();
		request.setAttribute("gb2_list", gb2_list);
		
		String gb2_idx = request.getParameter("gb2_idx");
		String gb2_name = request.getParameter("gb2_name");
		String gb2_subject = request.getParameter("gb2_subject");
		String gb2_regdate = request.getParameter("gb2_regdate");
		
		request.setAttribute("gb2_name", gb2_name);
		request.setAttribute("gb2_subject", gb2_subject);
		request.setAttribute("gb2_regdate", gb2_regdate);
	
		return "view/guestbook2/list.jsp";
	}

}
