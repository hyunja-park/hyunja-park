package com.ict.guestbook2.model;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GuestBook2DeleteCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		String gb2_idx = request.getParameter("gb2_idx");
		String idx = request.getParameter("gb2_pw");
		
		request.setAttribute("gb2_idx", gb2_idx);
		request.setAttribute("gb2_pw", gb2_pw);
		
		return "view/guestbook2/delete.jsp";
	}

}
