package com.ict.guestbook2.db;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class GuestBook2DAO {
	private static SqlSession ss;
	
	private synchronized static SqlSession getSession() {
		if(ss == null) {
			ss = GuestBook2DBservice.getFactory().openSession();
		}
		return ss;
	}

	public static List<GuestBook2VO> guestBook2ListAll(){
		List<GuestBook2VO> gb2_list = null;
		gb2_list = getSession().selectList("guestbook2.gb2_list"); 
		return gb2_list;
	}
		
	public static int guestBook2Insert(GuestBook2VO gb2vo) {
		int result = 0 ;
		result = getSession().insert("guestbook2.gb2_insert", gb2vo);
		ss.commit();
		return result;
	}
	
	public static GuestBook2VO guestBook2Detail(String gb2_idx) {
		GuestBook2VO gb2vo = null;
		gb2vo = getSession().selectOne("guestbook2.gb2_detail", gb2_idx);
		return gb2vo;
		
	}
	public static int guestBook2Update(GuestBook2VO gb2vo) {
		int result = 0 ;
		result = getSession().update("guestbook2.gb2_update", gb2vo);
		ss.commit();
		return result;
	}
	
	public static int guestBook2Delete(String gb2_idx) {
		int result = 0 ;
		result = getSession().delete("guestbook2.gb2_delete", gb2_idx);
		ss.commit();
		return result;
	}
			
}