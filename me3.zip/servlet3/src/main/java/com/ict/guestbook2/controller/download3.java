package com.ict.guestbook2.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import com.ict.file.model.Command;

@WebServlet("/download3")
public class download3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int utf = 0;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		

		String path = request.getServletContext().getRealPath("view/upload");
		String gb2_f_name = request.getParameter("gb2_f_name");
		
		// 웹 브라우저 문서 타입을 다운로드
		response.setContentType("application/x-msdownload");
		
	
		// 헤더 정보 변경
		response.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode(gb2_f_name, "utf-8"));
		
		// 실제 file 다운로드
		File file = new File(path + "/" + new String(gb2_f_name.getBytes(),"utf-8"));
		
		int b;
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		
		try {
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			bos = new BufferedOutputStream(response.getOutputStream());
			
			while ((b=bis.read()) != -1) {
				bos.write(b);
				bos.flush();
			}
		} catch (Exception e) {
			System.out.println(e);
		}finally {
			try {
				bos.close();
				bis.close();
				bos.close();
			} catch (Exception e2) {
				System.out.println(e2);
			}
		}

	
	}
}
