package com.ict.member.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.ict.member.model.Command;
import com.ict.member.model.JoinCommand;
import com.ict.member.model.JoinOKCommand;
import com.ict.member.model.LogInCommand;
import com.ict.member.model.LogInOKCommand;

@WebServlet("/LogInController")
public class LogInController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();

		String cmd = request.getParameter("cmd");		
		Command comm = null;
		switch (cmd) {
		case "m_login":	
			comm = new LogInCommand();
			break;

		case "m_join":		
			comm = new JoinCommand(); 
			break;
			
		case "m_join_ok":		
			comm = new JoinOKCommand(); 
			break;
			
		case "m_login_ok":		
			comm = new LogInOKCommand();
			break;
		}

			String path = comm.exec(request, response);
			
			// 결과를  보기 위해서 웹 페이지 이동(포워딩)
			request.getRequestDispatcher(path).forward(request, response);


		}


	}
	

