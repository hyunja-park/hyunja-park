package com.ict.member.model;

import com.ict.member.db.MemberDAO;
import com.ict.member.db.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JoinOKCommand implements Command {

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse reponse) {
		String m_id = request.getParameter("m_id");
		String m_pw = request.getParameter("m_pw");
		String m_name = request.getParameter("m_name");
		String m_age = request.getParameter("m_age");
		
		MemberVO mvo = new MemberVO();
		mvo.setM_id(m_id);
		mvo.setM_pw(m_pw);
		mvo.setM_name(m_name);
		mvo.setM_age(m_age);
		
		int result = MemberDAO.memberInsert(mvo);		
		if (result>0) {
			return "view/member/loginForm.jsp";
		}else {
			return "view/member/joinForm.jsp";
		}
			
		
	}
		
}

