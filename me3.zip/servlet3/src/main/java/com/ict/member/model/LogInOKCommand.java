package com.ict.member.model;

import com.ict.member.db.MemberDAO;
import com.ict.member.db.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LogInOKCommand implements Command{
	@Override
	public String exec(HttpServletRequest request, HttpServletResponse reponse) {
		String m_id = request.getParameter("m_id");
		String m_pw = request.getParameter("m_pw");
		
		MemberVO mvo = new MemberVO();
		mvo.setM_id(m_id);
		mvo.setM_pw(m_pw);
		
		// 로그인은 무조건 결과 하나 또는 실패
		MemberVO mvo2 = MemberDAO.memberSelectOne(mvo);
		
		request.setAttribute("mvo2", mvo2);
		
		return "view/member/result.jsp";
	}
}
