package com.ict.member.model;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JoinCommand implements Command {
	@Override
	public String exec(HttpServletRequest request, HttpServletResponse reponse) {
		// System.out.println("JoinCommand-exec 메서드");
		
		// 결과를 보여줄 jsp 파일 지정
		return "view/member/joinForm.jsp";
	}
}
