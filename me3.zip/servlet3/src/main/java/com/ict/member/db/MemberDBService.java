package com.ict.member.db;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MemberDBService {
	static private SqlSessionFactory factory;
	// config.xml 위치
	static String resource = "com/ict/member/db/member_config.xml";
	static {
		try {
			InputStream in = Resources.getResourceAsStream(resource);
			factory = new SqlSessionFactoryBuilder().build(in);
		} catch (Exception e) {
			System.out.println();
		}
	}
	
	// DAO에서 factory 를 호출할 메서드
	public static SqlSessionFactory getfFactory() {
		return factory;
	}
}
