package com.ict.member.db;

import org.apache.ibatis.session.SqlSession;

public class MemberDAO {
	private static SqlSession ss;
	
	private synchronized static SqlSession getseSession() {
		if (ss==null) {
			ss=MemberDBService.getfFactory().openSession();
		}
		return ss;
	}
	
	public static int memberInsert(MemberVO mvo) {
		int result = 0;
		result = getseSession().insert("member.insert", mvo);
		if (result>0) {
			ss.commit();
		}
		return result;
	}
	public static MemberVO memberSelectOne(MemberVO mvo) {
		MemberVO mvo2 = null;
		mvo2 = getseSession().selectOne("member.login", mvo);
		return mvo2;
	}
}
