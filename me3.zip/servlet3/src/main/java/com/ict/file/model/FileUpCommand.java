package com.ict.file.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig
public class FileUpCommand implements Command{

	@Override
	public String exec(HttpServletRequest request, HttpServletResponse response) {
		try {
			// 실제 저장 위치를 얻어내자.
			String path = request.getServletContext().getRealPath("view/upload");
			// System.out.println(path);
			
			// String name = request.getParameter("name");
			// String f_name = request.getParameter("f_name");
			// System.out.println("name : " + name);
			// System.out.println("f_name : " + f_name);
			
			// 서블릿 6.0을 사용하면 MultipartRequest 대신, getPart()사용
			// 파일 업로드를 하면 request 대신 사용하는 MultipartRequest클래스
			// MultipartRequest mr = 
			//		new MultipartRequest(request, path, 100*1024*100, "utf-8", new DefaultFileRenamePolicy())
			
			
			Part filePart = request.getPart("f_name");
			// DB에는 파일이 저장되는 것이 아니라 파일이름 또는 경로/파일이름을 저장하는 것이다.
			String fileName = filePart.getSubmittedFileName();
	         String uploadPath = path + "/" + fileName;

	         // 파일크기(바이트단위)
	         long fileSize = filePart.getSize();
	         double fileSizeMB = fileSize / (1024*1024.0);

	         // 파일 타입(MIME 타입)
	         String fileType = filePart.getContentType();

	         // 업로드 된 현재날짜 및 시간
	         LocalDateTime upTime = LocalDateTime.now();
	         DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	         String upTime2 = upTime.format(formatter);
	         
	         // 파일저장
	         filePart.write(uploadPath);

	         // 올린사람
	         String name = request.getParameter("name");

	         request.setAttribute("fileName", fileName);
	         request.setAttribute("fileSizeMB", fileSizeMB);
	         request.setAttribute("fileType", fileType);
	         request.setAttribute("upTime2", upTime2);
	         request.setAttribute("uploadPath", uploadPath);

	         return "view/file_up_down/fileUp_result.jsp";
	      } catch (Exception e) {
	         System.out.println(e);
	         return null;
	      }
	   }
	}