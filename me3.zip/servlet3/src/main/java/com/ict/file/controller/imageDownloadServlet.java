package com.ict.file.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/download")
public class imageDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String f_name = request.getParameter("f_name");
			String path = request.getServletContext().getRealPath("view/upload");

			File file = new File(path+"/"+f_name);

			if(! file.exists()) { // 존재하지 않으면
				response.sendError(HttpServletResponse.SC_FOUND);  // 404에러
				return;
			}
			//MIME 타입 설정
			response.setContentType(getServletContext().getMimeType(file.getName()));
			response.setContentLength((int)(file.length()));

			// 헤더 설정
			response.setHeader("Content-Disposition",
					"attachment; filename=\""+ file.getName()+"\"");

			// 파일을 읽고 클라이언트에 전송
			try(FileInputStream fileInputStream =  new FileInputStream(file);
					OutputStream OutputStream = response.getOutputStream()){
				byte[] buffer = new byte[(int)(file.length())];
				int b;
				while ((b = fileInputStream.read(buffer)) != -1) {
					OutputStream.write(buffer, 0 , b);
				}

			}

		} catch (Exception e) {


		}
	}
}



