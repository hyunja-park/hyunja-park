package com.ict.file.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.ict.file.model.Command;
import com.ict.file.model.FileFormCommand;
import com.ict.file.model.FileUpCommand;

@WebServlet("/FileController")
@MultipartConfig
public class FileController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	// TODO Auto-generated method stub
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();

		String cmd = request.getParameter("cmd");
		Command comm = null;
		switch (cmd) {
			case "file_form": comm = new FileFormCommand(); break;
			case "fileup": comm = new FileUpCommand(); break;


		}
		
		String path = comm.exec(request, response);
		request.getRequestDispatcher(path).forward(request, response);


	}


}
